# AemetOpenData.Model200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descripcion** | **String** |  | [default to &#39;Éxito&#39;]
**estado** | **Number** |  | 
**datos** | **String** |  | 
**metadatos** | **String** |  | 


