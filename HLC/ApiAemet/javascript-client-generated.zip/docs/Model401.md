# AemetOpenData.Model401

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descripcion** | **String** |  | [default to &#39;Unauthorized&#39;]
**estado** | **Number** |  | 


