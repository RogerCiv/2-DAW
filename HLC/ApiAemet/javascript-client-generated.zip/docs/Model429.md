# AemetOpenData.Model429

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descripcion** | **String** |  | [default to &#39;Too Many Requests&#39;]
**estado** | **Number** |  | 


