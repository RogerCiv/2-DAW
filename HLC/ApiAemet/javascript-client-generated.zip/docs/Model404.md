# AemetOpenData.Model404

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descripcion** | **String** |  | [default to &#39;Not Found&#39;]
**estado** | **Number** |  | 


