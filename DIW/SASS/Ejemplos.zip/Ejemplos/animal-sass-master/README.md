# Animal SASS

Pagina Animal, realizada como ejercicio de SASS, siguiendo el WorkShop realizado por la comunidad Medellin CSS.

[Demo del Proyecto](https://oriananohemi.github.io/animal-sass/)

<img src="./assets/Screen Shot 2020-08-30 at 17.31.32.png">
<img src="./assets/Screen Shot 2020-08-30 at 17.31.39.png">
