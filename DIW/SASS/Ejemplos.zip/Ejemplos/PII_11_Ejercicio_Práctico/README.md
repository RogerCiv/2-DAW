## Parte II.11 Ejercicio Práctico

Para finalizar el apartado de Sass vamos practicar lo que hemos visto en los apartado anteriores. Para ello el objetivo es que realicemos las siguiente taras:



* Estructurar todo los achivos  que hemos realizado en distintos ficheros temáticos y usar una hoja de estilos y una fuenta externa usando la directiva @import.
* Mejorar el sistema de maquetación creando dos breakpoints y usando la directiva @media.
* Crear mixins para prefijar ciertas propiedas y para realizar transformaciones que probaremos en una galería de imágenes.
* Documentar todo usando SassDoc




Curso desarrollado por @pekechis para @openwebinars
